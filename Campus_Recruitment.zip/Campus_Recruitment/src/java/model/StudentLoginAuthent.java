/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.MinorDatabase;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author LENOVO
 */
public class StudentLoginAuthent extends HttpServlet 
{
    public boolean isLoginStudent(String username,String password) throws ClassNotFoundException
    {
        String tablePassword="";
        try 
        {
          Class.forName("com.mysql.jdbc.Driver");
          System.out.println("Driver Loaded");
          
          Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projects","root","Rudraksh@123");
          System.out.println("Connected");
          Statement st= con.createStatement();
          String query = "Select password from student where username = '"+username.trim()+"'";
          System.out.println("query="+query);
          
          ResultSet rs=st.executeQuery(query);
            if(rs.next())
            {
                tablePassword=rs.getString(1);
            }
            else
            {
                return false;
            }
        } 
        catch (SQLException e) 
        {
            System.out.println(e);
        }
         if(username!=null && password!=null && password.equals(tablePassword))
        {
            return true;
        }
        return false;
    }
}
