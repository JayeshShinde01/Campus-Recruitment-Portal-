/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.MinorDatabase;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author LENOVO
 */
public class CoordinatorRegisterAuthent 
{
     public boolean coRegister(String username, String email, String phoneno, String password, String companyname, String companyaddress, String gender) throws ClassNotFoundException
    {
            try
            {
               Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");

                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projects","root","Rudraksh@123");
                System.out.println("Connected");
                //Connection con=MinorDatabase.getConnection();
                PreparedStatement pst=con.prepareStatement("INSERT INTO coordinator values(?,?,?,?,?,?,?)");
                
                pst.setString(1, username);
                pst.setString(2, email);
                pst.setString(3, phoneno);
                pst.setString(4, password);
                pst.setString(5, companyname);
                pst.setString(6, companyaddress);
                pst.setString(7, gender);
                int i=pst.executeUpdate();  
                System.out.println(i+" records inserted");
            }
            
           catch(SQLException e)
            {
                System.out.println(e);
            }
            
            if(username!=null && email!=null && phoneno!=null && password!=null && companyname!=null)
            {
                System.out.println("true");
                return true;
            }
            return false;
        }     
    
}
