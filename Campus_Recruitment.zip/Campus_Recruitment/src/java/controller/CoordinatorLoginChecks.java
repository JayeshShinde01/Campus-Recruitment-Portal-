/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CoordinatorLoginAuthent;
import model.StudentLoginAuthent;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/CoordinatorLoginChecks"))
public class CoordinatorLoginChecks extends HttpServlet 
{
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        response.sendRedirect("coordinator_login.html");
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        
        try {
            String username=request.getParameter("username");
            String password = request.getParameter("password");
            CoordinatorLoginAuthent cla=new CoordinatorLoginAuthent();
            boolean cologed = cla.isCoordinatorLogged(username, password);
            if(cologed)
            {
                HttpSession session = request.getSession(true);
                session.setAttribute("username", username);
                response.sendRedirect("coordinator_home.jsp");
            }
            else
            {
                response.sendRedirect("coordinator_login.html");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CoordinatorLoginChecks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
