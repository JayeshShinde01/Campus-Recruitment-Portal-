/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import db.MinorDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LENOVO
 */
@WebServlet(name = "Contactus", urlPatterns= ("/ContactUs"))
public class ContactUs extends HttpServlet 
{
    
    private static final long serialVersionUID = 1L;

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
         String Fullaname=request.getParameter("FullName");
         String Email= request.getParameter("Email");
         String Message= request.getParameter("Message");
            try
            {
               Class.forName("com.mysql.jdbc.Driver");
               System.out.println("Driver Loaded");

               Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projects", "root", "Rudraksh@123");
               System.out.println("Connected");

                //Connection con=MinorDatabase.getConnection();
                PreparedStatement pst=con.prepareStatement("INSERT INTO Contactus values(?,?,?)");
                
                pst.setString(1, Fullaname);
                pst.setString(2, Email);
                pst.setString(3,Message);
          
                int i=pst.executeUpdate();  
                System.out.println(i+" records inserted");
            
                if(i>=1)
                {
                    response.sendRedirect("contact_us.html");
                }
            
            }
            
           catch(SQLException e)
            {
                System.out.println(e);
            }catch (ClassNotFoundException ex) {
                Logger.getLogger(AddPlacementDetails.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
    }
    
