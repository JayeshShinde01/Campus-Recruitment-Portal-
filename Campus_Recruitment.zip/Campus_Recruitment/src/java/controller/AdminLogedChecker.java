/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.AdminLogedAuthent;

/**
 *
 * @author LENOVO
 */
//@WebServlet(urlPatterns= ("/AdminLogedChecker"))
@SuppressWarnings("serial")
@WebServlet(urlPatterns=("/AdminLogedChecker"))
public class AdminLogedChecker extends HttpServlet 
{
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        response.sendRedirect("admin_login.html");
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
    try {
        String adminusername=request.getParameter("adminusername");
        String adminpassword = request.getParameter("adminpassword");
        
        AdminLogedAuthent la=new AdminLogedAuthent();
        boolean loged = la.isLogedAdmin(adminusername, adminpassword);
        
        if(loged)
        {
            HttpSession session = request.getSession(true);
            session.setAttribute("adminusername", adminusername);
            response.sendRedirect("admin_home.jsp");
            System.out.println("I am here!!");
        }
        else
        {
            response.sendRedirect("admin_login.html");
            System.out.println("In hererererere!");
        }
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(AdminLogedChecker.class.getName()).log(Level.SEVERE, null, ex);
    }
    }    
   
}
