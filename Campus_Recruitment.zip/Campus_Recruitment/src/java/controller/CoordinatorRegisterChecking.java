/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CoordinatorRegisterAuthent;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/CoordinatorRegisterChecking"))
public class CoordinatorRegisterChecking extends HttpServlet 
{
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
     response.sendRedirect("admin_login.html");
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        try {
            System.out.println("hello in check reg");
            String username=request.getParameter("username");
            String email=request.getParameter("email");
            String phoneno=request.getParameter("phoneno");
            String password=request.getParameter("password");
            String companyname=request.getParameter("companyname");
            String companyaddress=request.getParameter("companyaddress");
            String gender=request.getParameter("gender");
            System.out.println(gender);
            
            CoordinatorRegisterAuthent sta=new CoordinatorRegisterAuthent();
            boolean coReg= sta.coRegister(username,email,phoneno,password,companyname,companyaddress,gender);
            
            if(coReg)
            {
                HttpSession session = request.getSession(true);
                session.setAttribute("username", username);
                session.setAttribute("email",email);
                session.setAttribute("phoneno", phoneno);
                session.setAttribute("password", password);
                session.setAttribute("dob", companyname);
                session.setAttribute("address", companyaddress);
                session.setAttribute("gender", gender);
                
                response.sendRedirect("admin_home.jsp");
            }
            else
            {
                response.sendRedirect("add_coordinat.html");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CoordinatorRegisterChecking.class.getName()).log(Level.SEVERE, null, ex);
        }
     
   }

}
