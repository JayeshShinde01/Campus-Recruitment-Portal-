/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/OtpChecker"))
public class OtpChecker extends HttpServlet 
{

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
       String otp=request.getParameter("otp");
       System.err.println("otp from html page:"+otp);
       //String recivedotp=request.getParameter("otprecived");
       //System.err.println("otp in hidden form:"+recivedotp);
  
        HttpSession session=request.getSession(true);  
        String otpreciver=(String)session.getAttribute("MailOtp");
        System.err.println("Hewllo the otp is :"+otpreciver);
       
       if(otp.equals(otpreciver))
       {
          response.sendRedirect("reset_password.html");
       }
       else
       {
           response.sendRedirect("otp_varification.jsp");
       }

        
    }
    
  
}
