/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import db.MinorDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/Applicationform"))
public class Applicationform extends HttpServlet 
{

    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
         String companyname=request.getParameter("c_name");
         String position=request.getParameter("position");

         String studentfirstname=request.getParameter("studentfirstname");
         String studentlastname= request.getParameter("studentlastname");
         String studentaddress= request.getParameter("studentaddress");
         String studentenrollment= request.getParameter("studentenrollment");
         String studentphoneno= request.getParameter("studentphoneno");
         String studentemailaddress= request.getParameter("studentemailaddress");
         String studentdepartment= request.getParameter("studentdepartment");
         String studentcourse= request.getParameter("studentcourse");
         String studentinsitute= request.getParameter("studentinsitute");
         
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver Loaded");
          
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projects","root","Rudraksh@123");
                System.out.println("Connected");
               
                PreparedStatement pst=con.prepareStatement("INSERT INTO student_placement_details values(?,?,?,?,?,?,?,?,?,?,?)");
                 
                pst.setString(1, companyname);
                 pst.setString(2, position);

                pst.setString(3, studentfirstname);
                pst.setString(4, studentlastname);
                pst.setString(5,studentaddress);
                pst.setString(6, studentenrollment);
                pst.setString(7, studentphoneno);
                pst.setString(8,studentemailaddress );
                pst.setString(9, studentdepartment);
               
                pst.setString(10, studentcourse);
                pst.setString(11,studentinsitute );
            
                int i=pst.executeUpdate();  
                System.out.println(i+" records inserted");
            
                if(i>=1)
                {
                    response.sendRedirect("Applied.html");
                }
            
            }
            
           catch(SQLException e)
            {
                System.out.println(e);
            } catch (ClassNotFoundException ex) {
            Logger.getLogger(Applicationform.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
        }     
 
  
    }

    

