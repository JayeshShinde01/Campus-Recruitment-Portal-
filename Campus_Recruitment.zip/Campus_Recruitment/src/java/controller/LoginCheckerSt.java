/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.StudentLoginAuthent;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/LoginCheckerSt"))
public class LoginCheckerSt extends HttpServlet 
{

     public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        response.sendRedirect("student_login.html");
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
     {     
         
         try {
             PrintWriter out = response.getWriter();
             
             
             String username=request.getParameter("username");
             String password = request.getParameter("password");
             
             StudentLoginAuthent sla=new StudentLoginAuthent();
             boolean login = sla.isLoginStudent(username, password);
             
             if(login)
             {
                 HttpSession session = request.getSession(true);
                 session.setAttribute("username", username);
                 response.sendRedirect("student_home.jsp");
             }
             else
             {
                 out.println("<html>");
                 out.println("<body>");
                 out.println("<span style=color:red><center>Number or password mismatch !!!</center></span>");
                 out.println("</body>");
                 out.println("</html>");
                 RequestDispatcher rd = request.getRequestDispatcher("/student_login.html");
                 rd.include(request, response);
                 // response.sendRedirect("student_login.html");
             }} catch (ClassNotFoundException ex) {
             Logger.getLogger(LoginCheckerSt.class.getName()).log(Level.SEVERE, null, ex);
         }
    }    
   
}
