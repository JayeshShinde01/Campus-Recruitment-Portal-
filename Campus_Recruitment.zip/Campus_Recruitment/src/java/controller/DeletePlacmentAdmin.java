/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import db.MinorDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/DeletePlacmentAdmin"))
public class DeletePlacmentAdmin extends HttpServlet {

    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
            String companyname=request.getParameter("companyname");
            try
            {
               Class.forName("com.mysql.jdbc.Driver");
               System.out.println("Driver Loaded");

               Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projects", "root", "Rudraksh@123");
               System.out.println("Connected");               
                //Connection con=MinorDatabase.getConnection();
                Statement   st = con.createStatement();

            String query = "DELETE FROM placements where company_name='"+companyname+"' ";
                System.err.println("query"+query);

            int i = st.executeUpdate(query);

            if(i>0)
            {
                System.out.println(i+" Record Deleted..");
            }
            else
            {
                System.out.println("Record Deletion Failed...");
            }
            if(i>0)
            {
                response.sendRedirect("campus_placements.jsp");
            }
            con.close();
        }
            
            
         catch (SQLException e) 
        {
            System.out.println(e);
        }catch (ClassNotFoundException ex) {
                Logger.getLogger(AddPlacementDetails.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}

