/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;



import java.io.IOException;
//import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.StudentRegAuthent;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.StudentRegAuthent;

/**
 *
 * @author LENOVO
 */
@WebServlet(urlPatterns= ("/StudentRegCheck"))
public class StudentRegCheck extends HttpServlet 
{
     
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
     response.sendRedirect("student_registration.html");
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
            try {
                System.out.println("hello in check reg");
                String username=request.getParameter("username");
                String email=request.getParameter("email");
                String phoneno=request.getParameter("phoneno");
                String password=request.getParameter("password");
                String dob=request.getParameter("dob");
                String address=request.getParameter("address");
                String gender=request.getParameter("gender");
                System.out.println(gender);
                
                StudentRegAuthent sta=new StudentRegAuthent();
                boolean registerst= sta.isRegister(username,email,phoneno,password,dob,address,gender);
                
                if(registerst)
                {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("username", username);
                    session.setAttribute("email",email);
                    session.setAttribute("phoneno", phoneno);
                    session.setAttribute("password", password);
                    session.setAttribute("dob", dob);
                    session.setAttribute("address", address);
                    session.setAttribute("gender", gender);
                    
                    response.sendRedirect("student_login.html");
                }
                else
                {
                    response.sendRedirect("student_registration.html");
                }   } catch (ClassNotFoundException ex) {
                Logger.getLogger(StudentRegCheck.class.getName()).log(Level.SEVERE, null, ex);
            }
     
   }
}
